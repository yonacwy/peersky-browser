import { isOpera, isWebkit } from '../utils/browser-info.js';
import { debugMode } from '../utils/debug.js';
import store from '../npm/hybrids/src/store.js';

const TRUSTED_DOMAINS_NONE_ID = "<none>";
const ManagedConfig = {
  disableOnboarding: false,
  disableUserControl: false,
  disableUserAccount: false,
  disableTrackersPreview: false,
  // TODO: Update the structure of `trustedDomains` as is with `customFilters`
  // to have `enabled` flag and `domains` array
  trustedDomains: [TRUSTED_DOMAINS_NONE_ID],
  customFilters: { enabled: false, filters: [String] },
  disableNotifications: (config) => config.disableOnboarding || config.disableUserControl,
  disableModes: (config) => config.disableOnboarding || config.disableUserControl || config.trustedDomains[0] !== TRUSTED_DOMAINS_NONE_ID || config.customFilters.enabled,
  [store.connect]: async () => {
    if (isOpera() || isWebkit()) return {};
    try {
      let managedConfig = await chrome.storage.managed.get().catch((e) => {
        if (debugMode) return {};
        throw e;
      });
      if (true) {
        if (Object.keys(managedConfig).length) {
          chrome.storage.local.set({ managedConfig });
        } else {
          const { managedConfig: fallbackConfig } = await chrome.storage.local.get("managedConfig");
          managedConfig = fallbackConfig;
        }
      }
      if (managedConfig.customFilters) {
        managedConfig.customFilters = {
          enabled: true,
          filters: managedConfig.customFilters
        };
      }
      return managedConfig || {};
    } catch {
      return {};
    }
  }
};

export { TRUSTED_DOMAINS_NONE_ID, ManagedConfig as default };
